import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.KeyEvent;

public class Hero 
	{
	int X;
	Hero(int a)
		{
		X=a;
		}
	public void draw(Graphics g)
		{
		g.setColor(Color.red);
		g.fillRect(X, 500, 25, 25);
		}
	public void moveLeft()
		{
		X=X-10;
		}
	public void moveRight()
		{
		X=X+10;
		}
	public void whichkey(int inKey) 
		{
		if(inKey==KeyEvent.VK_LEFT) 
			{
			moveLeft();
			}
		if(inKey==KeyEvent.VK_RIGHT) 
			{
			moveRight();
			}
		}
	}


