import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;

public class HeroBullet 
	{
	int x;
	int y=0;   
	public void move ()
		{
		y=y-10;
		}
	public void draw(Graphics g)
		{
		g.fillOval(x,y,10,10);
		}
	public Rectangle getRectangle() {
		Rectangle r=new Rectangle(x,y,10,10);
		return r;	
	}
	public void whichKey(int inKey,int heroX)
	{
	if(inKey==KeyEvent.VK_SPACE)
		{
			y=500;
			x=heroX+05;
		}
	}
	

	}
