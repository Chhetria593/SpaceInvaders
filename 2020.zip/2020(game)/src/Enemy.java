import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;

public class Enemy 
	{
	int enemyX=0;  
	int enemyY=0;
	int dx = 10;
	
	Enemy(int a,int b)
		{
		enemyX=a;
		enemyY=b;
		}
	public void draw(Graphics g)
		{
		g.setColor(Color.blue);
		g.fillRect(enemyX, enemyY, 25, 25);
		}
	public boolean move()
		{
		enemyX=enemyX+dx;
		if(enemyX>550||enemyX<25)
			{
			return true;
			}
		return false;
		}
	public void collision(Rectangle br)
		{
		Rectangle r=new Rectangle(enemyX,enemyY,25,25);
		boolean b=r.intersects(br);
		if(b==true) 
			{
			enemyY=600;
			}
		}
	public void switchDirection()
		{
		if(dx==10)
			{
			dx=-10;
			}
		else 
			{
			dx=10;
			}
		}
	}
